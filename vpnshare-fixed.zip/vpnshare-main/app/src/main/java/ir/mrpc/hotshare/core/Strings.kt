package ir.mrpc.hotshare.core

/** All user-facing text. Persian when the system language is Persian, English otherwise. */
class Strings(val fa: Boolean) {
    companion object {
        fun system() = Strings(Prefs.lang == "fa")
    }

    private fun t(f: String, e: String) = if (fa) f else e

    val appName get() = "HotShare"
    val tagline get() = t("اشتراک امن VPN با دستگاه‌های اطراف", "Share your VPN with people nearby")
    val designedBy get() = "Designed by Mr.PC"

    // Navigation
    val navHome get() = t("خانه", "Home")
    val navMenu get() = t("منو", "Menu")
    val navHelp get() = t("راهنما", "Help")
    val back get() = t("بازگشت", "Back")
    val cancel get() = t("انصراف", "Cancel")
    val ok get() = t("تأیید", "OK")
    val close get() = t("بستن", "Close")

    // Home
    val hello get() = t("خوش آمدید", "Welcome")
    val chooseRole get() = t("امروز چه کاری انجام بدهیم؟", "What would you like to do?")
    val shareTitle get() = t("اشتراک VPN", "Share VPN")
    val shareDesc get() = t("VPN گوشی‌ات را با دستگاه‌های نزدیک به اشتراک بگذار", "Let nearby devices use your phone's VPN")
    val receiveTitle get() = t("دریافت VPN", "Get VPN")
    val receiveDesc get() = t("نزدیک‌ترین دستگاه را پیدا کن و وصل شو", "Find the nearest device and connect")
    val statusTitle get() = t("وضعیت شما", "Your status")
    val chipVpn get() = "VPN"
    val chipWifi get() = "Wi-Fi"
    val chipBluetooth get() = t("بلوتوث", "Bluetooth")
    val on get() = t("روشن", "On")
    val off get() = t("خاموش", "Off")
    val active get() = t("فعال", "Active")
    val inactive get() = t("غیرفعال", "Inactive")

    // Host
    val hostTitle get() = t("اشتراک VPN", "Share VPN")
    val stepHotspot get() = t("هات‌اسپات", "Hotspot")
    val stepVpn get() = "VPN"
    val stepVisible get() = t("قابل مشاهده برای اطراف", "Visible to nearby")
    val hotspotAuto get() = t("هات‌اسپات خودکار آماده است", "Auto hotspot is ready")
    val hotspotSystem get() = t("هات‌اسپات گوشی روشن است", "Phone hotspot is on")
    val hotspotWaiting get() = t("در حال آماده‌سازی…", "Preparing…")
    val hotspotOff get() = t("هات‌اسپات خاموش است", "Hotspot is off")
    val openHotspot get() = t("روشن کردن هات‌اسپات", "Turn on hotspot")
    val hotspotNote get() = t(
        "اندروید اجازه نمی‌دهد برنامه‌ها هات‌اسپات گوشی را مستقیم روشن کنند. صفحه‌ی تنظیمات باز می‌شود؛ پس از روشن شدن، برنامه خودکار متوجه می‌شود.",
        "Android doesn't let apps switch the phone hotspot on directly. Settings will open; the app notices automatically once it's on.")
    val vpnOn get() = t("VPN شما فعال است", "Your VPN is active")
    val vpnOff get() = t("VPN پیدا نشد", "No VPN found")
    val vpnNote get() = t("اول برنامه VPN خودت را باز و روشن کن، بعد به اینجا برگرد. اگر VPN روشن نباشد، اینترنت دیگران بدون VPN خارج می‌شود.", "Open your VPN app and turn it on first, then come back. Without a VPN, others' traffic leaves unprotected.")
    val visibleOn get() = t("دستگاه‌های اطراف شما را می‌بینند", "Nearby devices can see you")
    val visibleOff get() = t("بلوتوث یا مجوز فعال نیست", "Bluetooth or permission is off")
    val startShare get() = t("شروع اشتراک", "Start sharing")
    val stopShare get() = t("توقف اشتراک", "Stop sharing")
    val sharing get() = t("در حال اشتراک‌گذاری", "Sharing now")
    val scanHint get() = t("این QR را روی گوشی دوم اسکن کنید", "Scan this QR on the other phone")
    val codeLabel get() = t("کد اتصال", "Connection code")
    val copy get() = t("کپی", "Copy")
    val copied get() = t("کپی شد", "Copied")
    val newCode get() = t("کد جدید", "New code")
    val devices get() = t("دستگاه", "Devices")
    val upload get() = t("ارسال", "Sent")
    val download get() = t("دریافت", "Received")
    val wifiNetwork get() = t("شبکه‌ی وای‌فای", "Wi-Fi network")
    val wifiPassword get() = t("رمز وای‌فای", "Wi-Fi password")
    val approveTitle get() = t("درخواست اتصال", "Connection request")
    val approveBody get() = t("می‌خواهد از VPN شما استفاده کند.", "wants to use your VPN.")
    val allow get() = t("اجازه", "Allow")
    val deny get() = t("رد کردن", "Deny")
    val notifAskTitle get() = t("درخواست اتصال جدید", "New connection request")

    // Receive / radar
    val receiveHeader get() = t("دریافت VPN", "Get VPN")
    val searching get() = t("در حال جستجوی دستگاه‌های اطراف…", "Looking for devices nearby…")
    val nearest get() = t("نزدیک‌ترین", "Nearest")
    val tapToConnect get() = t("برای اتصال لمس کنید", "Tap to connect")
    val connectNow get() = t("اتصال", "Connect")
    val nothingFound get() = t("دستگاهی پیدا نشد. با QR یا کد وصل شوید.", "No device found. Connect with a QR or a code.")
    val scanQr get() = t("اسکن QR", "Scan QR")
    val enterCode get() = t("وارد کردن کد", "Enter code")
    val permNearby get() = t("برای پیدا کردن دستگاه‌های اطراف، مجوز «دستگاه‌های اطراف» لازم است.", "Allow “Nearby devices” so we can find phones around you.")
    val permGrant get() = t("اجازه دادن", "Grant access")
    val btOffNote get() = t("بلوتوث خاموش است.", "Bluetooth is off.")
    val btTurnOn get() = t("روشن کردن بلوتوث", "Turn on Bluetooth")

    // Scanner
    val scanTitle get() = t("اسکن QR", "Scan QR")
    val scanPrompt get() = t("QR را داخل کادر قرار دهید", "Point the camera at the QR code")
    val scanInvalid get() = t("این QR مربوط به HotShare نیست", "This isn't a HotShare QR code")
    val camPerm get() = t("برای اسکن QR دسترسی به دوربین لازم است.", "Camera access is needed to scan the QR code.")
    val torch get() = t("چراغ قوه", "Torch")

    // Code entry
    val codeTitle get() = t("کد ۸ رقمی", "8-digit code")
    val codeSub get() = t("کدی که روی گوشی میزبان نمایش داده می‌شود را وارد کنید", "Type the code shown on the host phone")

    // Wi-Fi sheet
    val wifiSheetTitle get() = t("اتصال به وای‌فای میزبان", "Join the host's Wi-Fi")
    val wifiSheetSub get() = t("نام و رمز هات‌اسپات گوشی میزبان را وارد کنید", "Enter the host phone's hotspot name and password")
    val wifiWrong get() = t("اتصال انجام نشد؛ نام یا رمز را بررسی کنید.", "Couldn't join. Check the name and password.")
    val joinWifi get() = t("اتصال به وای‌فای", "Join Wi-Fi")
    val showPass get() = t("نمایش رمز", "Show password")

    // Connect flow
    val connectingTo get() = t("در حال اتصال به", "Connecting to")
    val stageRequest get() = t("درخواست از میزبان", "Asking the host")
    val stageRequestDone get() = t("میزبان تأیید کرد", "Host approved")
    val stageWifi get() = t("اتصال به وای‌فای", "Joining Wi-Fi")
    val stageVerify get() = t("بررسی میزبان و کد", "Checking host & code")
    val stageTunnel get() = t("ساخت تونل امن VPN", "Creating secure tunnel")
    val connected get() = t("متصل شدید", "You're connected")
    fun routedVia(h: String) = if (fa) "اینترنت شما از VPN «$h» عبور می‌کند" else "Your traffic goes through $h's VPN"
    val duration get() = t("مدت اتصال", "Duration")
    val disconnect get() = t("قطع اتصال", "Disconnect")
    val retry get() = t("تلاش دوباره", "Try again")
    val failedTitle get() = t("اتصال برقرار نشد", "Couldn't connect")

    val errCode get() = t("کد اشتباه است.", "Wrong code.")
    val errUnreach get() = t("میزبان در دسترس نیست. مطمئن شوید میزبان اشتراک را شروع کرده است.", "Host not reachable. Make sure the host has started sharing.")
    val errNative get() = t("موتور تونل در این نسخه نصب نشده یا اجرا نشد.", "The tunnel engine is missing or failed to start.")
    val errVpn get() = t("مجوز VPN داده نشد.", "VPN permission was not granted.")
    val errLost get() = t("ارتباط با میزبان قطع شد.", "Connection to the host was lost.")
    val errQr get() = t("QR نامعتبر است.", "Invalid QR code.")
    val errDenied get() = t("میزبان درخواست را رد کرد یا پاسخ نداد.", "The host declined or didn't answer.")
    val errBle get() = t("ارتباط بلوتوثی با میزبان برقرار نشد. دوباره تلاش کنید یا از QR استفاده کنید.", "Couldn't reach the host over Bluetooth. Try again or use the QR code.")
    val errWifi get() = t("اتصال به وای‌فای میزبان انجام نشد.", "Couldn't join the host's Wi-Fi.")
    val errCanceled get() = t("اتصال لغو شد.", "Connection canceled.")

    // Menu / settings
    val menuTitle get() = t("منو", "Menu")
    val secQuick get() = t("دسترسی سریع", "Quick actions")
    val secSharing get() = t("اشتراک‌گذاری", "Sharing")
    val secAppearance get() = t("ظاهر", "Appearance")
    val secDevice get() = t("دستگاه", "Device")
    val secSupport get() = t("پشتیبانی", "Support")
    val theme get() = t("پوسته", "Theme")
    val themeSystem get() = t("سیستم", "System")
    val themeLight get() = t("روشن", "Light")
    val themeDark get() = t("تیره", "Dark")
    val autoHotspot get() = t("هات‌اسپات خودکار", "Auto hotspot")
    val autoHotspotDesc get() = t("هات‌اسپات اختصاصی برنامه را خودکار می‌سازد", "Creates an app hotspot automatically")
    val autoStart get() = t("شروع خودکار اشتراک", "Auto-start sharing")
    val autoStartDesc get() = t("وقتی هات‌اسپات روشن شد", "When your hotspot turns on")
    val autoApprove get() = t("تأیید خودکار دستگاه‌ها", "Approve devices automatically")
    val autoApproveDesc get() = t("بدون پرسیدن، اتصال دستگاه‌های نزدیک را بپذیر", "Accept nearby devices without asking")
    val hotspotDetails get() = t("مشخصات هات‌اسپات", "Hotspot details")
    val hotspotDetailsDesc get() = t("نام و رمز هات‌اسپات گوشی را یک‌بار ذخیره کنید", "Save your phone hotspot name and password once")
    val keepOn get() = t("روشن ماندن صفحه", "Keep screen on")
    val keepOnDesc get() = t("هنگام اشتراک یا اتصال", "While sharing or connected")
    val battery get() = t("بهینه‌سازی باتری", "Battery optimization")
    val batteryDesc get() = t("برای اینکه اشتراک در پس‌زمینه قطع نشود", "So sharing isn't stopped in the background")
    val regen get() = t("ساخت کد جدید", "Generate new code")
    val regenDesc get() = t("دستگاه‌های قبلی دیگر نمی‌توانند وصل شوند", "Previously paired devices can no longer connect")
    val save get() = t("ذخیره", "Save")
    val howTitle get() = t("راهنمای استفاده", "How it works")
    val privacyTitle get() = t("حریم خصوصی", "Privacy")
    val aboutTitle get() = t("درباره‌ی برنامه", "About")
    val version get() = t("نسخه", "Version")
    val helpHost get() = if (fa) listOf(
        "VPN خودت را روشن کن (از خود برنامه VPN).",
        "برنامه را باز کن و «اشتراک VPN» را بزن.",
        "هر وقت برنامه بلوتوث یا مجوزی خواست، فقط «اجازه» را بزن.",
        "دکمه «شروع اشتراک» را بزن. هات‌اسپات خودکار ساخته می‌شود؛ اگر نشد، هات‌اسپات گوشی را دستی روشن کن.",
        "وقتی دوستت درخواست داد «اجازه» را بزن؛ یا QR یا کد را به او بده.",
        "تا وقتی دیگران وصل‌اند برنامه را نبند. برای پایان، «توقف اشتراک» را بزن."
    ) else listOf(
        "Turn on your VPN (from your VPN app).",
        "Open this app and tap Share VPN.",
        "When the app asks for Bluetooth or a permission, just tap Allow.",
        "Tap Start sharing. An app hotspot is created automatically; if not, turn on your phone hotspot manually.",
        "When your friend asks to join tap Allow, or hand over the QR / code.",
        "Keep the app open while others are connected. Tap Stop sharing when you're done."
    )
    val helpClient get() = if (fa) listOf(
        "مطمئن شو VPN دیگری روی گوشی تو روشن نیست.",
        "«دریافت VPN» را بزن و بلوتوث و مجوزها را وقتی خواست روشن کن.",
        "اسم گوشی میزبان روی رادار می‌آید؛ لمسش کن (یا QR را اسکن کن، یا کد را بزن).",
        "اگر لازم شد رمز هات‌اسپات را وارد کن و پیام VPN اندروید را تأیید کن.",
        "وقتی «متصل شدید» را دیدی، اینترنتت از VPN دوستت می‌گذرد."
    ) else listOf(
        "Make sure no other VPN is on, on your phone.",
        "Tap Get VPN and turn on Bluetooth / permissions when asked.",
        "The host's name appears on the radar; tap it (or scan the QR, or type the code).",
        "If asked, enter the hotspot password and approve Android's VPN prompt.",
        "When you see “You're connected”, your traffic goes through your friend's VPN."
    )
    val shareHeader get() = t("برای میزبان", "For the host")
    val clientHeader get() = t("برای دریافت‌کننده", "For the receiver")
    val privacy get() = t(
        "HotShare هیچ داده‌ای جمع‌آوری نمی‌کند، تبلیغ ندارد و به سرور خارجی وصل نمی‌شود. ترافیک فقط بین دو گوشی و با کد اتصال رد‌وبدل می‌شود. کد را فقط به افراد مورد اعتماد بدهید.",
        "HotShare collects no data, shows no ads and talks to no external server. Traffic only flows between the two phones, protected by the pairing code. Share the code only with people you trust.")

    // Notifications
    val notifTitle get() = t("HotShare در حال اشتراک‌گذاری است", "HotShare is sharing your VPN")
    val notifText get() = t("برای توقف، دکمه‌ی زیر را بزنید", "Tap stop to end sharing")
    val notifStop get() = t("توقف", "Stop")

    // ───────────── Numbers ─────────────
    fun n(i: Int): String =
        if (fa) i.toString().map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("") else i.toString()

    // ───────────── Language ─────────────
    val language get() = t("زبان", "Language")
    val langFa get() = "فارسی"
    val langEn get() = "English"
    val secLook get() = t("زبان و ظاهر", "Language & look")
    val secStart get() = t("شروع سریع", "Quick start")
    val secHelpGroup get() = t("راهنما و پشتیبانی", "Help & support")

    // ───────────── Fix-it actions ─────────────
    val fixTurnOn get() = t("روشن کن", "Turn on")
    val fixGrant get() = t("اجازه بده", "Allow")
    val fixOpen get() = t("باز کن", "Open")
    val tapToFix get() = t("لمس کن تا روشن شود", "Tap to turn on")
    val homeNotReady get() = t("چند مورد آماده نیست", "A few things aren't ready")
    val homeNotReadyDesc get() = t("بلوتوث یا وای‌فای خاموش است؛ برای درست کردن لمس کنید", "Bluetooth or Wi-Fi is off. Tap to fix it")
    val chipHint get() = t("اگر مورد خاموشی دیدید، رویش بزنید تا برنامه درخواست روشن‌شدن بدهد.", "If something is off, tap it and the app will ask to turn it on.")
    val wifiOffNote get() = t("وای‌فای خاموش است؛ برای اتصال به میزبان لازم است.", "Wi-Fi is off. It's needed to join the host.")
    val turnOnWifi get() = t("روشن کردن وای‌فای", "Turn on Wi-Fi")

    // ───────────── Setup screen ─────────────
    val setupTitle get() = t("آماده‌سازی دستگاه", "Get your phone ready")
    val setupRowDesc get() = t("بلوتوث، وای‌فای، مجوزها و VPN را یک‌جا ببین و روشن کن", "Check and switch on Bluetooth, Wi-Fi, permissions and VPN in one place")
    val setupIntro get() = t(
        "اندروید اجازه نمی‌دهد برنامه‌ها بی‌صدا بلوتوث یا وای‌فای را روشن کنند. برای هر مورد نارنجی دکمه‌اش را بزن؛ پنجره‌ی خود اندروید باز می‌شود و فقط «اجازه» را بزن.",
        "Android doesn't let apps switch Bluetooth or Wi-Fi on silently. Tap the button on any orange item; Android shows its own prompt and you just tap Allow.")
    val setupReceiverTitle get() = t("اگر می‌خواهی VPN بگیری", "If you want to get a VPN")
    val setupHostTitle get() = t("اگر می‌خواهی VPN بدهی", "If you want to share a VPN")
    val setupAllReady get() = t("همه‌چیز آماده است", "All set")
    val reqNearby get() = t("مجوز دستگاه‌های اطراف", "Nearby devices permission")
    val reqNearbyDesc get() = t("برای پیدا کردن گوشی‌های نزدیک", "To find phones around you")
    val reqHostPerm get() = t("مجوزهای اشتراک", "Sharing permissions")
    val reqHostPermDesc get() = t("بلوتوث، هات‌اسپات و اعلان", "Bluetooth, hotspot and notifications")
    val reqBluetooth get() = t("بلوتوث", "Bluetooth")
    val reqBluetoothClientDesc get() = t("تا میزبان روی رادار پیدا شود", "So the host shows up on the radar")
    val reqBluetoothHostDesc get() = t("تا گوشی‌های اطراف تو را ببینند", "So nearby phones can see you")
    val reqWifi get() = t("وای‌فای", "Wi-Fi")
    val reqWifiDesc get() = t("برای وصل شدن به هات‌اسپات میزبان", "To join the host's hotspot")
    val reqCamera get() = t("دوربین", "Camera")
    val reqCameraDesc get() = t("فقط برای اسکن QR (اختیاری)", "Only for scanning QR codes (optional)")
    val reqVpn get() = t("VPN روشن", "VPN on")
    val reqVpnDesc get() = t("برنامه VPN خودت را روشن کن", "Turn on your own VPN app")
    val reqHotspot get() = t("هات‌اسپات", "Hotspot")
    val reqHotspotDesc get() = t("اگر هات‌اسپات خودکار کار نکرد، دستی روشنش کن", "If the auto hotspot doesn't work, turn it on manually")
    val reqBattery get() = t("بهینه‌سازی باتری", "Battery optimization")
    val reqBatteryDesc get() = t("تا اشتراک در پس‌زمینه قطع نشود (پیشنهادی)", "So sharing isn't stopped in the background (recommended)")

    // ───────────── Privacy screen ─────────────
    val privacyIntro get() = t("چه چیزی با اطلاعات تو اتفاق می‌افتد؟", "What happens to your data?")

    // ───────────── Illustrated tour ─────────────
    val tourStart get() = t("شروع آموزش تصویری", "Start the visual tour")
    val tourStartDesc get() = t("با دایره و فلش، بخش‌های برنامه را یکی‌یکی نشانت می‌دهیم", "We'll point at each part of the app with circles and arrows")
    val tourSkip get() = t("رد کردن", "Skip")
    val tourNext get() = t("بعدی", "Next")
    val tourPrev get() = t("قبلی", "Back")
    val tourDoneBtn get() = t("فهمیدم", "Got it")
    fun tourStepOf(i: Int, total: Int) = if (fa) "مرحله ${n(i)} از ${n(total)}" else "Step $i of $total"

    val tourShareTitle get() = t("اشتراک VPN", "Share VPN")
    val tourShareBody get() = t("اگر خودت VPN داری و می‌خواهی دوستت هم از آن استفاده کند، اینجا را بزن.", "If you have a VPN and want a friend to use it too, tap here.")
    val tourReceiveTitle get() = t("دریافت VPN", "Get VPN")
    val tourReceiveBody get() = t("اگر VPN نداری و می‌خواهی از گوشی دوستت استفاده کنی، اینجا را بزن.", "If you don't have a VPN and want to use a friend's, tap here.")
    val tourStatusTitle get() = t("وضعیت گوشی تو", "Your phone's status")
    val tourStatusBody get() = t("بلوتوث، وای‌فای و VPN را اینجا می‌بینی. اگر چیزی خاموش بود روی همان بزن تا برنامه درخواست روشن‌شدن بدهد.", "Bluetooth, Wi-Fi and VPN show here. If something is off, tap it and the app will ask to turn it on.")
    val tourMenuTitle get() = t("منو و تنظیمات", "Menu & settings")
    val tourMenuBody get() = t("زبان، پوسته، هات‌اسپات خودکار و «آماده‌سازی دستگاه» اینجاست.", "Language, theme, auto hotspot and “Get your phone ready” live here.")
    val tourHelpTitle get() = t("راهنما", "Help")
    val tourHelpBody get() = t("هر وقت گیج شدی بیا اینجا؛ همه‌چیز قدم‌به‌قدم توضیح داده شده.", "Come here whenever you're unsure; everything is explained step by step.")

    val tourHostCheckTitle get() = t("چک‌لیست اشتراک", "Sharing checklist")
    val tourHostCheckBody get() = t("سه مورد باید سبز باشد: هات‌اسپات، VPN و قابل مشاهده بودن. هر موردی نارنجی بود، دکمه‌اش را بزن.", "Three things should be green: hotspot, VPN and visibility. Tap the button on any orange one.")
    val tourHostStartTitle get() = t("شروع اشتراک", "Start sharing")
    val tourHostStartBody get() = t("وقتی آماده شدی این را بزن؛ QR و کد اتصال نشان داده می‌شود.", "When you're ready tap this; the QR and connection code appear.")
    val tourHostQrTitle get() = t("QR اتصال", "Connection QR")
    val tourHostQrBody get() = t("QR را به گوشی دوم نشان بده تا اسکن کند.", "Show this QR to the other phone to scan.")
    val tourHostCodeTitle get() = t("کد ۸ رقمی", "8-digit code")
    val tourHostCodeBody get() = t("اگر اسکن QR سخت بود، همین کد را به او بگو تا وارد کند.", "If scanning is hard, tell them this code to type in.")

    val tourRadarTitle get() = t("رادار", "Radar")
    val tourRadarBody get() = t("اسم گوشی تو وسط است و گوشی‌های نزدیک دورش ظاهر می‌شوند. روی هرکدام بزنی، درخواست اتصال می‌رود.", "Your phone's name is in the middle and nearby phones appear around it. Tap one to ask to connect.")
    val tourRecvActionsTitle get() = t("اگر پیدا نشد", "If nothing shows up")
    val tourRecvActionsBody get() = t("با «اسکن QR» یا «وارد کردن کد» هم می‌شود وصل شد. فقط یکی را انتخاب کن.", "You can also connect with “Scan QR” or “Enter code”. Pick just one.")

    // ───────────── Help screen ─────────────
    val helpWhichTitle get() = t("کدام را انتخاب کنم؟", "Which one should I pick?")
    val helpHostCardTitle get() = t("من VPN دارم و می‌خواهم بدهم", "I have a VPN and want to share it")
    val helpHostCardBody get() = t("گوشی تو «میزبان» می‌شود. لازم داری: ۱) VPN روشن ۲) بلوتوث روشن ۳) هات‌اسپات (خودکار ساخته می‌شود).", "Your phone becomes the host. You need: 1) VPN on 2) Bluetooth on 3) a hotspot (created automatically).")
    val helpGoHost get() = t("رفتن به اشتراک VPN", "Go to Share VPN")
    val helpClientCardTitle get() = t("من VPN ندارم و می‌خواهم بگیرم", "I need a VPN and want to get one")
    val helpClientCardBody get() = t("گوشی تو «دریافت‌کننده» می‌شود. لازم داری: ۱) بلوتوث و وای‌فای روشن ۲) مجوز دستگاه‌های اطراف ۳) دوستت میزبان باشد.", "Your phone becomes the receiver. You need: 1) Bluetooth and Wi-Fi on 2) Nearby devices permission 3) a friend who is hosting.")
    val helpGoClient get() = t("رفتن به دریافت VPN", "Go to Get VPN")
    val helpMethodsTitle get() = t("سه روش اتصال (فقط یکی کافی است)", "Three ways to connect (you only need one)")
    val helpMethodRadar get() = t("رادار (ساده‌ترین)", "Radar (easiest)")
    val helpMethodRadarDesc get() = t("بلوتوث را روشن بگذار؛ گوشی میزبان خودش روی رادار می‌آید. فقط لمسش کن.", "Keep Bluetooth on; the host appears on the radar by itself. Just tap it.")
    val helpMethodQr get() = t("اسکن QR", "Scan QR")
    val helpMethodQrDesc get() = t("اگر رادار چیزی پیدا نکرد: میزبان QR را نشان بدهد و تو اسکن کنی.", "If the radar finds nothing: the host shows a QR and you scan it.")
    val helpMethodCode get() = t("کد ۸ رقمی", "8-digit code")
    val helpMethodCodeDesc get() = t("اگر دوربین نداری یا QR خوانده نشد: کدی را که روی گوشی میزبان است تایپ کن.", "No camera, or the QR won't scan: type the code shown on the host phone.")
    val helpStepsTitle get() = t("قدم‌به‌قدم", "Step by step")
    val helpFaqTitle get() = t("مشکل دارم", "Something's wrong")
    val helpFaq get() = if (fa) listOf(
        "دستگاه روی رادار نمی‌آید" to "بلوتوث هر دو گوشی روشن باشد، میزبان «شروع اشتراک» را زده باشد و فاصله کم باشد. اگر باز هم نیامد از QR یا کد استفاده کن.",
        "به وای‌فای وصل نمی‌شود" to "نام و رمز هات‌اسپات را دقیق وارد کن و مطمئن شو هات‌اسپات میزبان روشن است.",
        "وصل شدم ولی اینترنت ندارم" to "VPN روی گوشی میزبان باید خودش وصل و سالم باشد. اول روی همان گوشی تستش کن.",
        "بلوتوث یا وای‌فای خودش روشن نمی‌شود" to "اندروید اجازه‌ی روشن کردن بی‌صدا را نمی‌دهد؛ برنامه پنجره‌ی درخواست را نشان می‌دهد و تو فقط «اجازه» را بزن. «آماده‌سازی دستگاه» در منو همه را یک‌جا نشان می‌دهد.",
        "هات‌اسپات خودکار ساخته نشد" to "بعضی گوشی‌ها پشتیبانی نمی‌کنند. هات‌اسپات گوشی را از تنظیمات روشن کن؛ برنامه خودش تشخیص می‌دهد."
    ) else listOf(
        "The device doesn't show on the radar" to "Bluetooth must be on for both phones, the host must have tapped Start sharing, and you should be close. Otherwise use the QR or the code.",
        "It won't join the Wi-Fi" to "Type the hotspot name and password exactly, and make sure the host's hotspot is on.",
        "Connected but no internet" to "The VPN on the host phone must be connected and working. Test it on that phone first.",
        "Bluetooth or Wi-Fi won't turn on by itself" to "Android doesn't allow silent switching; the app shows the prompt and you just tap Allow. “Get your phone ready” in the menu shows everything in one place.",
        "The auto hotspot wasn't created" to "Some phones don't support it. Turn on the phone hotspot in Settings; the app detects it automatically."
    )
}
